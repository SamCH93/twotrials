# twotrials

The **twotrials** R package provides functions to ... The theoretical background
of the package is described in

Pawel, S. and Held, L. (2025). Compatible Effect Estimation and Hypothesis
Testing in Drug Regulation. <https://doi.org/XXXX>

## Installation

```r
## CRAN version
install.packages("twotrials")

## from GitHub
## install.packages("remotes") # requires remotes package
remotes::install_github(repo = "SamCH93/twotrials", subdir = "package")
```

## Usage

...
