# twotrials 0.05

- new functions `twotrials`, `p2TR`, `pMA`, `pEdgington`, `pFisher`, `pPearson`,
  `pTippett` to compute combined p-values from two parameter estimates and their
  standard errors
