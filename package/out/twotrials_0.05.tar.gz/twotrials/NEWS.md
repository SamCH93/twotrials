# twotrials 0.05

- package development started
- new functions `twotrials`, `p2TR`, `pMA`, `pEdgington`, `pFisher`, `pPearson`,
  `pTippett`, `mu2TR`, `muMA`, `muEdgington`, `muFisher`, `muPearson`,
  `muTippett` to conduct combined p-value function inference from two parameter
  estimates and their standard errors
